import os
# import random
import numpy as np
from typing import List
from dirs_pos_tuple import Dirs_pos_tuple
from question_tuple import Question_tuple

# from dirs_data_tuple import Dirs_data_tuple
from dirs_data_dict import dirs_data_dict

def get_txt_files(directory_path: str):
    txt_files = []
    for filename in os.listdir(directory_path):
        if filename.endswith('.txt'):
            txt_files.append(filename)
    return txt_files

def word_count(s: str):
    words = s.split()
    return len(words)

def ptk_question_from_sect(label: str, qs: str):
    s = f"\n\npage: begin\n\nl: {label}\nt: scale gender\no: free\n"
    s += f"q: {qs}\n- \n\n"
    s += f"l: no_{label}\nt: radio\no: free\nq: <i></i>\n- <i> Non so / Preferisco non rispondere\n\npage: end\n\n"
    return s

def q_vec_from_file(dir_path: str, file_name: str, minw: int, maxw: int ):
    '''
    Riceve la posizione della directory, il nome del file, numero minimo e n massimo di parole per sezione.

    Per creare una sezione unisce una frase alla volta fino a trovare un
    numero di parole per sezione >= minw e <= di maxw.
    Ogni sezione così creata viene poi trasformata in una domanda in codice
    psytoolkit (aka ptk) da ptk_question_from_sect.
    Genera una label per ogni domanda come unione del nome del file (e.g.
    "F22"), "_", e il numero di sezione nel testo.

    Ritorna un array: (numero di frasi nel file, lista di question_tuple nel file(label, domanda ptk)).
    '''
    file_path = dir_path + file_name
    f_label = file_name.split('_', maxsplit=1)[0] # Parte prima di '_'
    quest_list = []
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()
        text = '.'.join(text.splitlines()) # Rimuovere '\n'
        sentences = text.split('.') # Dividere per frasi
        ind = 0
        while ind < len(sentences):
            # Filtraggio frasi minori di 5 caratteri
            if len(sentences[ind]) < 5:
                sentences.pop(ind)
            else:
                ind += 1
        s_n = len(sentences)
        sect_index = 1 # Indice sezione nel testo
        sect = ""
        for s in sentences:
            clean = s + '. '
            # Se la frase ha da sola num sufficiente di parole diventa 
            # una sezione
            if word_count(clean) >= minw:
                sect_label = f_label + '_' + str(sect_index)
                new_q = Question_tuple(label=sect_label, text=ptk_question_from_sect(sect_label, clean))
                quest_list.append(new_q)
                sect_index += 1
                sect=""
                continue
            sect += clean
            w = word_count(sect)
            if w >= minw:
                if w <= maxw:
                    sect_label = f_label + '_' + str(sect_index)
                    new_q = Question_tuple(label=sect_label, text=ptk_question_from_sect(sect_label, sect))
                    quest_list.append(new_q)
                    sect_index += 1
                else:
                    # Test print
                    print(f"Too big. Not considered because {w} words.")
                sect = ""
    return (s_n, quest_list)


def extraction(minw: int, maxw: int, data_pos: Dirs_pos_tuple, dest: str ):
    '''
    Ritrova le directory agli indirizzi forniti da data_pos che devono essere nell'ordine [f_pos, m_pos, n_pos].
    Per ogni directory un ciclo su ogni file estrae le sezioni di testo e le loro label, il numero di frasi nel file richiamando q_vec_from_file.
    Salva la lista di domande, il numero di frasi ed il numero di domande ottenute da ogni directory in un dizionario definito in dirs_data_dict e sintetizza i dati ottenuti nel file outputs/summary.txt.
    L'oggetto data_dirs_tuple infine viene salvato alla posizione indicata da dest in un file .npy utilizzando numpy.save().
    '''
    # Directories: Female, Male, Neutri
    dirs_pos = data_pos
    dirs_data = dirs_data_dict
    # Questions extract
    for ind, d in enumerate(dirs_pos):
        # Get all files in the directory
        d_files = get_txt_files(d)
        d_q = []
        d_sentences_n = 0
        d_q_n = 0
        d_f_n = len(d_files)
        for d_f in d_files:
            # Extract sections to be used as questions
            n_s, file_quests = q_vec_from_file(d, d_f, minw, maxw)
            d_sentences_n += n_s
            for fq in file_quests:
                d_q.append(fq)
                d_q_n += 1
        # Save
        # Dirs_pos_tuple([0]female, [1]male, [2]neutral)
        if ind == 0:
            dirs_data['f_nsent'] = d_sentences_n
            dirs_data['f_nquest'] = d_q_n
            dirs_data['f_list'] = d_q
            dirs_data['f_nfiles'] = d_f_n
        if ind == 1:
            dirs_data['m_nsent'] = d_sentences_n
            dirs_data['m_nquest'] = d_q_n
            dirs_data['m_list'] = d_q
            dirs_data['m_nfiles'] = d_f_n
        if ind == 2:
            dirs_data['n_nsent'] = d_sentences_n
            dirs_data['n_nquest'] = d_q_n
            dirs_data['n_list'] = d_q
            dirs_data['n_nfiles'] = d_f_n


    # Summary File Creation or clearing:
    with open("outputs\\summary.txt", "w", encoding='utf-8') as f:
        f.write('')
    # Summary Writing
    with open("outputs\\summary.txt", "a", encoding='utf-8') as f:
        s = f"Domande composte da sezioni di testo (unione di frasi intere) con un minimo di {minw} parole ed un massimo di {maxw} parole\n\n"

        s += "\n\nCARTELLA FEMMINILE:"
        s += f"\n\t Numero di file di testo:\t{dirs_data['f_nfiles']}\n"
        s += f"\n\t Numero di frasi totale:\t{dirs_data['f_nsent']}\n"
        s += f"\n\t Numero di domande ottenute:\t{dirs_data['f_nquest']}\n"

        s += "\n\nCARTELLA MASCHILE:"
        s += f"\n\t Numero di file di testo:\t{dirs_data['m_nfiles']}\n"
        s += f"\n\t Numero di frasi totale:\t{dirs_data['m_nsent']}\n"
        s += f"\n\t Numero di domande ottenute:\t{dirs_data['m_nquest']}\n"

        s += "\n\nCARTELLA NEUTRA:"
        s += f"\n\t Numero di file di testo:\t{dirs_data['n_nfiles']}\n"
        s += f"\n\t Numero di frasi totale:\t{dirs_data['n_nsent']}\n"
        s += f"\n\t Numero di domande ottenute:\t{dirs_data['n_nquest']}\n"
        f.write(s)

    # SALVATAGGIO DATI ESTRATTI IN dest
    np.save(dest, dirs_data)

    # tot_nq = f_nq+m_nq+n_nq
    # fc = fem_q
    # mc = male_q
    # nc = neu_q

    # # Distribute questions in pages
    # n_pgs = tot_nq//nqpage
    # pages = [ [] for _ in range(n_pgs) ]
    # index = 0
    # while len(fc) > 0 or len(mc) > 0 or len(nc) > 0:
    #     if len(fc) > 0:
    #         rand_f = random.randint(0, len(fc) - 1)
    #         pages[index%n_pgs].append(fc.pop(rand_f))
    #         index+=1
    #     if len(mc) > 0:
    #         rand_m = random.randint(0, len(mc) - 1)
    #         pages[index%n_pgs].append(mc.pop(rand_m))
    #         index+=1
    #     if len(nc) > 0:
    #         rand_n = random.randint(0, len(nc) - 1)
    #         pages[index%n_pgs].append(nc.pop(rand_n))
    #         index+=1

    # # Control print
    # pg_n = 1
    # for p in pages:
    #     print(f"\n Page {pg_n}:\t{len(p)} pages")
    #     pg_n+=1

    # #Survey Writing

    # # Pages preparation
    # psy_pgs = []
    # pg_id = 1
    # for p in pages:
    #     label = f"{pg_id}_"
    #     questions = []
    #     while len(p) > 0:
    #         rand_ind = random.randrange(len(p))
    #         rand_q = p.pop(rand_ind) # (label, text of question)
    #         label += rand_q[0]
    #         questions.append(rand_q[1])
    #     psy_pgs.append(psytool_page(label, questions))
    #     pg_id+=1

    # # Pages store in npy file
    # np.save(dest, psy_pgs)