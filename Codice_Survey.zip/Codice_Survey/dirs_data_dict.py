
dirs_data_dict = {

    'f_list': [],
    'm_list': [],
    'n_list': [],

    'f_nsent': 0,
    'm_nsent': 0,
    'n_nsent': 0,

    'f_nquest': 0,
    'm_nquest': 0,
    'n_nquest': 0,

    'f_nfiles': 0,
    'm_nfiles': 0,
    'n_nfiles': 0
}