from typing import NamedTuple
from typing import List
from question_tuple import Question_tuple

class Dirs_data_tuple(NamedTuple):
    '''
    For each directory 
    '''
    f_list: List[Question_tuple]
    m_list: List[Question_tuple]
    n_list: List[Question_tuple]

    f_nsent: int
    m_nsent: int
    n_nsent: int

    f_nquest: int
    m_nquest: int
    n_nquest: int

    f_nfiles: int
    m_nfiles: int
    n_nfiles: int