from typing import NamedTuple

class Dirs_pos_tuple(NamedTuple):
    f_pos: str
    m_pos: str
    n_pos: str