from typing import NamedTuple

class Question_tuple(NamedTuple):
    label: str
    text: str