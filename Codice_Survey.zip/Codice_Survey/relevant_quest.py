import numpy as np
import json
import data_extract
import re
# from typing import List
from dirs_pos_tuple import Dirs_pos_tuple
from dirs_data_dict import dirs_data_dict


dest_file = 'extracted_data\\dirs_data.npy'

# All directories data
data_ndarray = np.load(dest_file, allow_pickle=True)
data_dict = data_ndarray.item()

s_q_list = "F27_4_1;F4_3_1;F21_13_1;F4_1_1;F23_2_1;F14_3_1;F28_4_1;M10_19_1;F13_5_1;F30_26_1;F14_5_1;F19_19_1;F24_16_1;N6_6_1;F19_4_1;F13_2_1;F18_1_1;F12_4_1;F9_20_1;N15_20_1;N29_21_1;F25_32_1;F15_1_1;F20_6_1;F21_6_1;F22_5_1;M25_1_1;N14_14_1;N14_25_1;N29_22_1;N29_23_1;F1_27_1;M10_1_1;M19_15_1;N14_3_1;N29_1_1;F14_7_1;F25_8_1;F16_2_1;F15_6_1;M29_2_1;F6_23_1;N11_18_1;F17_7_1;F26_3_1;M12_3_1;M28_9_1;N14_10_1;F5_6_1;N30_1_1;F19_12_1;F26_5_1;N13_1_1;N3_6_1;F19_14_1;N3_10_1;F6_7_1;N15_15_1;N15_5_1;N29_14_1;N5_14_1;F19_5_1;F1_2_1;F25_14_1;F9_9_1;N13_2_1;F32_18_1;F6_29_1;M16_19_1;N1_27_1;N25_3_1;F24_2_1;F32_36_1;F32_8_1;F32_19_1;F32_25_1;F9_19_1;N3_12_1;F24_13_1;F24_20_1;F24_6_1;F9_14_1;M10_16_1;M19_6_1;M2_3_1;M20_8_1;M24_14_1;M24_7_1;M9_16_1;M9_20_1;N11_12_1;N12_7_1;N15_16_1;N17_4_1;N17_5_1;N21_8_1;N4_35_1;N4_5_1;N5_11_1;N6_9_1;N7_24_1;N9_34_1;F11_5_1;N23_3_1;N4_36_1;M3_2_1;N12_19_1;F6_16_1;N16_2_1;N18_8_1;N25_4_1;N15_11_1;N19_5_1;N2_21_1;N4_37_1;N4_7_1;M1_9_1;M6_9_1;N17_2_1;F32_9_1;M10_25_1;M11_18_1;M2_8_1;M24_20_1;M25_14_1;M27_9_1;N1_24_1;N12_2_1;M16_7_1;N14_4_1;N9_8_1;M21_11_1;M19_14_1;M16_9_1;M11_3_1;M3_10_1;N29_5_1;M16_10_1;M16_16_1;M9_2_1;F7_2_1;M16_33_1;M24_18_1;M8_14_1;M22_3_1;M4_6_1;M4_2_1;M28_5_1;M12_9_1;M29_3_1;M8_8_1;M13_8_1;M13_14_1;M12_16_1;M13_11_1;M27_25_1"

s_score_list = "-1.857142857;-1.8;-1.75;-1.714285714;-1.666666667;-1.6;-1.6;-1.6;-1.571428571;-1.555555556;-1.5;-1.5;-1.5;-1.5;-1.428571429;-1.4;-1.285714286;-1.2;-1.2;-1.2;-1.2;-1.142857143;-1;-1;-1;-1;-1;-1;-1;-1;-1;-0.875;-0.857142857;-0.833333333;-0.833333333;-0.833333333;-0.75;-0.666666667;-0.625;-0.6;-0.6;-0.571428571;-0.571428571;-0.5;-0.5;-0.5;-0.5;-0.5;-0.428571429;-0.428571429;-0.4;-0.4;-0.4;-0.4;-0.375;-0.333333333;-0.285714286;-0.285714286;-0.25;-0.25;-0.25;-0.222222222;-0.2;-0.2;-0.2;-0.2;-0.166666667;-0.166666667;-0.166666667;-0.166666667;-0.166666667;-0.142857143;-0.142857143;-0.142857143;-0.125;-0.111111111;-0.111111111;-0.111111111;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0.111111111;0.111111111;0.111111111;0.142857143;0.142857143;0.166666667;0.166666667;0.166666667;0.166666667;0.2;0.2;0.2;0.2;0.2;0.333333333;0.333333333;0.333333333;0.4;0.4;0.4;0.4;0.4;0.4;0.4;0.4;0.4;0.428571429;0.428571429;0.428571429;0.5;0.571428571;0.666666667;0.8;0.8;0.8;0.833333333;0.833333333;0.833333333;1;1;1;1;1.142857143;1.142857143;1.2;1.285714286;1.428571429;1.428571429;1.5;1.6;1.888888889;2;2;2"

# test = "page: begin\n\nl: F4_3\nt: scale gender\no: free\nq:  guarda qui:.  Il reggiseno ti parla. Ora, non è che proprio dice delle parole, ma se a fine giornata ti viene voglia di guardarlo bruciare, può darsi che lui non sia quello giusto per te.\n-\nl: no_F4_3\nt: radio\no: free\nq: <i></i>\n- <i> Non so / Preferisco non rispondere\npage: end"

def extract_text(s: str)->str:
    occurrences = re.findall(r"q:.*", s)
    sect =  occurrences[0]
    return sect[2:]


q_list = s_q_list.split(';')
labels = []
for ind, l in enumerate(q_list):
    labels.append(l[:-2])
    
# print(f"\n\nProva estrazione: \n{extract_text(test)}\n\n******\n")

scores = s_score_list.split(';')

# Il testo come codice psytoolkit di tutte le domande estratte
all_ptk_quest = []
ptk_tuple = []
for ls in ('f_list', 'm_list', 'n_list'):
    for q_tup in data_dict[ls]:
        all_ptk_quest.append(q_tup.text)
        ptk_tuple.append(q_tup)

result = ""

for ind, ql in enumerate(labels):
    print(f"\ncerco: {ql}")
    section = ""
    found = False
    for q in ptk_tuple:
        if q.label == ql:
            section = extract_text(q.text)
            found = True
            break
    if found:
        result += f"{ql};{section};{scores[ind]}\n"
    else:
        print("ERRORE")

text_file = open("risultati_e_sezioni.txt", "w", encoding='utf-8')
text_file.write(result)
text_file.close()

print(result)