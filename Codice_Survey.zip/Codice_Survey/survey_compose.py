import numpy as np
import json
import data_extract
# from typing import List
from dirs_pos_tuple import Dirs_pos_tuple
from dirs_data_dict import dirs_data_dict

DIR_POS = Dirs_pos_tuple(f_pos="dataset\\Female\\", m_pos="dataset\\Male\\", n_pos="dataset\\Neutral\\")

'''
Parametres for questions extraction from dataset.
Note: changing these variables leads to execution of 'data_extract.py'
generating new questions with different labels.
'''
MINW = 30 # Min number of words in a survey question
MAXW = 70 # Max number of words in a survey question
# NQPAGE = 5 # Number of questions per page

# Parametres for survey assembly
SUB_QUEST = 18 # Number of questions per sub-survey
PERSONAL_DATA_SURVEY_POS = "scritte_survey\\dati_personali_survey.txt"
INTRO_SUB_POS = "scritte_survey\\intro_sub_survey.txt"

# Output survey location
survey_path = "outputs\\survey.txt"

# Parametres for data collection
EXP_PARTICIPANTS = 100  # Number of expected participants
N_ANS = 7  # Target number of answers per question
DONE_SUBS = 0  # Sub-surveys already answered by sufficient participants
SAFE_RATIO = 0.9  # Reduce n of choosable sub-surveys to
# prevent unbalance in number of answers per sub due to random choice

# Data store files
c_file = 'ext_config.json' # Variabili per l'estrazione
dest_file = 'extracted_data\\dirs_data.npy' # Dati estratti dall'ultima chiamata a extraction

# Check extraction variables
with open(c_file, 'r') as f:
    e_v = json.load(f)
first_ex = e_v['first']
changed = (e_v['MINW'] != MINW or e_v['MAXW'] != MAXW)
# changed = True

if first_ex or changed: # Necessaria nuova estrazione
    # Estrazione
    data_extract.extraction(MINW, MAXW, DIR_POS, dest_file)
    print("\n\nNuova estrazione delle domande effettuata, rissunto in outputs/summary.txt\n\n")
    # Aggiornamento file configurazione
    e_v['first'] = False 
    e_v['MINW'], e_v['MAXW'] = MINW, MAXW
    with open(c_file, 'w') as f:
        json.dump(e_v, f)

# All directories data
data_ndarray = np.load(dest_file, allow_pickle=True)
data_dict = data_ndarray.item()

# Il testo come codice psytoolkit di tutte le domande estratte
all_ptk_quest = []
for ls in ('f_list', 'm_list', 'n_list'):
    for q_tup in data_dict[ls]:
        all_ptk_quest.append(q_tup.text)

'''
# **** Extraction Test *****
print(f"\nFemale:\tnum_frasi\t{data_dict['f_nsent']}\tnum_domande\t{data_dict['f_nquest']}\n")
for i in range(5):
    quest = data_dict['f_list'][i]
    print(f"\tlabel:\t{quest.label}\ttext:\n{quest.text}")

print(f"\nMale:\tnum_frasi\t{data_dict['m_nsent']}\tnum_domande\t{data_dict['m_nquest']}\n")
for i in range(5):
    quest = data_dict['m_list'][i]
    print(f"\tlabel:\t{quest.label}\ttext:\n{quest.text}")

print(f"\nNeutral:\tnum_frasi\t{data_dict['n_nsent']}\tnum_domande\t{data_dict['n_nquest']}\n")
for i in range(5):
    quest = data_dict['n_list'][i]
    print(f"\tlabel:\t{quest.label}\ttext:\n{quest.text}")
# ****************************
'''

# Survey components

# Scale
# scale = """scale: gender
# item: Risposta
# - {score=0} Non so / Preferisco non rispondere
# - {score=-2} Completamente femminile
# - {score=-1} Più femminile che maschile
# - {score=0} Neutro
# - {score=1} Più maschile che femminile
# - {score=2} Completamente maschile\n\n"""

scale = """scale: gender
item: <i></i>
- {score=-2} Completamente femminile
- {score=-1} Più femminile che maschile
- {score=0} Neutro
- {score=1} Più maschile che femminile
- {score=2} Completamente maschile\n\n"""

# Intro Sub-survey
sub_intro = ""
with open(INTRO_SUB_POS, 'r', encoding='utf-8') as s_intro_file:
    sub_intro = s_intro_file.read()

personal_intro = "\n\n#################################\n###############################\n## PERSONAL DATA ##################\n\nl: personal_data_intro \nt: info \nq: Grazie per aver aver completato la prima parte del sondaggio, segue qualche breve domanda su di lei per fini statistici.\nSi ricorda che le sue risposte saranno mantenute anonime.\n\n"

personal_questions = ""
with open(PERSONAL_DATA_SURVEY_POS, 'r', encoding='utf-8') as dp:
    personal_questions = dp.read()

# Number of sub surveys
subn = len(all_ptk_quest)//SUB_QUEST

# File Creation or clearing:
with open(survey_path, "w", encoding='utf-8') as s:
    s.write('')

def test_quest1(subn: int) -> str: # RISPOSTA ATTESA: 2
    return f"\npage: begin\n\nl: test1_{subn}\nt: scale gender\no: free\nq: Un altro aspetto da considerare, come si è detto, è la determinazione dell’efficacia e della sicurezza del farmaco nelle donne che sono le più esposte alla demenza di Alzheimer per svariate ragioni. Questa è una domanda di prova, risponda: Completamente Maschile\n- \n\n\nl: no_test1{subn}\nt: radio\no: free\nq: <i></i>\n- <i> Non so / Preferisco non rispondere </i>\n\npage: end\n\n"

def test_quest2(subn: int) -> str: # RISPOSTA ATTESA: -1
    return f"\npage: begin\n\nl: test2_{subn}\nt: scale gender\no: free\nq: L'effetto dell'instabilità strutturale permanente, della fine della visione «di lungo corso», non può che essere stagnazione e conservazione, altro che innovazione. Questa è una domanda di prova, risponda: Più femminile che maschile\n- \n\n\nl: no_test2{subn}\nt: radio\no: free\nq: <i></i>\n- <i> Non so / Preferisco non rispondere<i>\n\npage: end\n\n"

# Survey Writing
with open(survey_path, "a", encoding='utf-8') as survey:
    # Scale
    survey.write(scale)

    # Selezione dei sub-surveys che possono essere proposti in
    # base al numero di partecipanti attesi
    choosable = int((EXP_PARTICIPANTS/N_ANS)*SAFE_RATIO + 0.5)
    end = DONE_SUBS + choosable
    # Choose Random
    survey.write(f"l: choose_sub \nt: set \n- random {DONE_SUBS} {end}")
    # Jump
    survey.write("\n\nl:\nt: jump")
    for i in range(subn):
        survey.write("\n- if $choose_sub == "+str(i)+ " then goto sub_intro_"+str(i))
    survey.write("\n\n")

    #Sub-surveys
    for i in range(subn):
        #Intro
        survey.write("\n\n## Sub-survey " + str(i) + "##################\n\nl: sub_intro_"+str(i) +"\nt: info \nq: <i>[sub-codice: "+ str(i) + "]</i>"+ sub_intro)
        # survey.write("\n\nrandom: begin\n\n") #Randomization of sub questions

        # Questions
        n_q_written = 0
        while n_q_written < SUB_QUEST: # 20 -2 per domande test
        #while n_q_written < 1: # 20 -2 per domande test
            # Select a random question from the pool:
            rand_ind = np.random.randint(len(all_ptk_quest))
            new_q = all_ptk_quest.pop(rand_ind)
            survey.write(new_q)
            n_q_written += 1

        # for n_p in range(SUBPGS):
        #     survey.write( psy_pgs[0] )
        #     psy_pgs = np.delete(psy_pgs, 0)

        # Domanda di prova
        survey.write(test_quest1(i))
        survey.write(test_quest2(i))
        # End
        # survey.write("\n\nrandom: end\n\n")
        # survey.write("\n\nl: sub_end_"+str(i) +"\nt: jump \n- goto personal_data_intro")
        survey.write("\n\nl: sub_end_"+str(i) +"\nt: jump \n- goto language\n\n")
    print(f"\n\nScartate {len(all_ptk_quest)} domande\n\nFINE")
    # survey.write(personal_intro)
    survey.write(personal_questions)
    # Final print
    print(f" OUTPUT Survey in {survey_path}")